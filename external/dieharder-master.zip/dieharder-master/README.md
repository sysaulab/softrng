
## dieharder

### Status

This is the maintenance "upstream" repo to regroup updates made for the
[Debian package dieharder](https://tracker.debian.org/pkg/dieharder).

The repo was spawned off the [Debian package
repo](https://salsa.debian.org/edd/dieharder) and contains its full history,
which includes the full package history as well.

There is another repo [containing mostly Robert's
work](https://github.com/eddelbuettel/dieharder-rgb) as transfered from the
old Google Code SVN repo.

### Maintainer

Dirk Eddelbuettel

### Authors

Robert G. Brown, Dirk Eddelbuettel, David Bauer
